#!/system/bin/sh
MODDIR=${0%/*}
# 设置所有相关属性
resetprop -n ro.boot.vbmeta.device_state locked
resetprop -n ro.boot.vbmeta.invalidate_on_error yes
resetprop -n ro.boot.vbmeta.avb_version 2.0
resetprop -n ro.boot.vbmeta.hash_alg sha256
resetprop -n ro.boot.vbmeta.size 65536